# Projet 1 — Analyse des journaux d'un pare-feu

**Auteur : DIALLO Kadidia**

## Lancer le projet
```bash
pip install -r requirements.txt
python analyse.py
```
Le script lit `data/logs_reseau.csv`, nettoie les données, écrit `resultats.json`
et enregistre les figures dans `figures/`. L'interprétation est dans `rapport.md`.
