"""Analyse des journaux d'un pare-feu : nettoyage, résultats, figures.

Usage : python analyse.py
"""
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # pas besoin d'écran
import matplotlib.pyplot as plt
import pandas as pd

DATA = Path("data/logs_reseau.csv")
FIG_DIR = Path("figures")
OUT = Path("resultats.json")


def nettoyer(df: pd.DataFrame) -> pd.DataFrame:
    """Doublons exacts, protocole en majuscules, bytes_sent manquants -> médiane."""
    df = df.drop_duplicates().copy()
    df["protocol"] = df["protocol"].str.strip().str.upper()
    df["bytes_sent"] = pd.to_numeric(df["bytes_sent"], errors="coerce")
    df["bytes_sent"] = df["bytes_sent"].fillna(df["bytes_sent"].median())
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    return df


def calculer_resultats(df: pd.DataFrame) -> dict:
    taux_deny = (df["action"].str.upper() == "DENY").mean() * 100
    return {
        "nb_lignes_apres_nettoyage": int(len(df)),
        "top_port": int(df["dst_port"].value_counts().idxmax()),
        "taux_deny_pct": round(float(taux_deny), 2),
        "ip_scanner": str(df.groupby("src_ip")["dst_port"].nunique().idxmax()),
        "ip_exfiltration": str(df.groupby("src_ip")["bytes_sent"].sum().idxmax()),
    }


def sauver(fig, nom: str) -> None:
    fig.tight_layout()
    fig.savefig(FIG_DIR / nom, dpi=120)
    plt.close(fig)


def faire_figures(df: pd.DataFrame) -> None:
    FIG_DIR.mkdir(exist_ok=True)

    # 1. Top 10 des ports
    fig, ax = plt.subplots(figsize=(8, 5))
    top = df["dst_port"].value_counts().head(10)
    ax.bar(top.index.astype(str), top.values, color="steelblue")
    ax.set_title("Top 10 des ports de destination")
    ax.set_xlabel("Port de destination")
    ax.set_ylabel("Nombre de connexions")
    sauver(fig, "top_ports.png")

    # 2. Connexions par heure
    fig, ax = plt.subplots(figsize=(8, 5))
    par_heure = df["timestamp"].dt.hour.value_counts().sort_index()
    ax.plot(par_heure.index, par_heure.values, marker="o")
    ax.set_title("Connexions par heure de la journée")
    ax.set_xlabel("Heure")
    ax.set_ylabel("Nombre de connexions")
    ax.set_xticks(range(0, 24, 2))
    ax.grid(alpha=0.3)
    sauver(fig, "connexions_par_heure.png")

    # 3. Octets par type d'appareil
    fig, ax = plt.subplots(figsize=(8, 5))
    vol = df.groupby("device_type")["bytes_sent"].sum().sort_values(ascending=False)
    ax.bar(vol.index, vol.values, color="darkorange")
    ax.set_title("Volume d'octets envoyés par type d'appareil")
    ax.set_xlabel("Type d'appareil")
    ax.set_ylabel("Octets envoyés (total)")
    sauver(fig, "octets_par_appareil.png")

    # 4. ALLOW / DENY
    fig, ax = plt.subplots(figsize=(6, 6))
    rep = df["action"].str.upper().value_counts()
    ax.pie(rep.values, labels=rep.index, autopct="%1.1f%%", startangle=90)
    ax.set_title("Répartition ALLOW / DENY")
    sauver(fig, "allow_deny.png")

    # 5. Ports distincts contactés par IP (top 10) -> repère le scanner
    fig, ax = plt.subplots(figsize=(8, 5))
    ports = df.groupby("src_ip")["dst_port"].nunique().sort_values(ascending=False).head(10)
    ax.barh(ports.index[::-1], ports.values[::-1], color="firebrick")
    ax.set_title("Ports distincts contactés par IP source (top 10)")
    ax.set_xlabel("Nombre de ports distincts")
    ax.set_ylabel("IP source")
    sauver(fig, "ports_distincts_par_ip.png")


def afficher_preuves(df: pd.DataFrame, res: dict) -> None:
    """Chiffres utiles pour rédiger le rapport (affichés dans le terminal)."""
    scan = df[df["src_ip"] == res["ip_scanner"]]
    exfil = df[df["src_ip"] == res["ip_exfiltration"]]
    print("\n--- PREUVES POUR LE RAPPORT ---")
    print(f"Scanner {res['ip_scanner']} : {scan['dst_port'].nunique()} ports distincts, "
          f"{len(scan)} connexions, {(scan['action'].str.upper() == 'DENY').mean() * 100:.1f}% DENY")
    print(f"Exfiltration {res['ip_exfiltration']} : {exfil['bytes_sent'].sum():,.0f} octets au total "
          f"({exfil['bytes_sent'].sum() / df['bytes_sent'].sum() * 100:.1f}% du trafic), "
          f"appareil(s) : {', '.join(exfil['device_type'].astype(str).unique())}, "
          f"ports : {[int(p) for p in sorted(exfil['dst_port'].unique())[:10]]}")
    print("Top 5 ports :", df["dst_port"].value_counts().head(5).to_dict())
    print("Octets par appareil :", df.groupby("device_type")["bytes_sent"].sum().round().to_dict())
    print("Connexions par heure (top 3) :", df["timestamp"].dt.hour.value_counts().head(3).to_dict())


def main() -> None:
    df = nettoyer(pd.read_csv(DATA))
    resultats = calculer_resultats(df)
    OUT.write_text(json.dumps(resultats, indent=2, ensure_ascii=False), encoding="utf-8")
    faire_figures(df)
    print(json.dumps(resultats, indent=2, ensure_ascii=False))
    afficher_preuves(df, resultats)


if __name__ == "__main__":
    main()
